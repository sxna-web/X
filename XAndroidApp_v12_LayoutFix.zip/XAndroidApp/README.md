# X Android WebView wrapper

## V12 layout and accessibility corrections

- Native root applies the measured Android status-bar and display-cutout inset, then adds a 24dp touch-safe gap. This moves the WebView viewport itself below the status bar on every page, rather than attempting to compensate individual X page elements.
- The native root clips to its padded content area so WebView content cannot draw back into the status-bar/cutout region.
- The home feed's `为你推荐 / 正在关注` (or `For you / Following`) tab strip is pinned only when both expected labels are present. Other page tab bars and profile/avatar headers remain in normal flow so their hit targets are not detached from their content.
- Login label replacement scans dynamic text and accessibility attributes; a narrow visual fallback covers only the matching label if X re-creates it, without covering the input control.
- Network failures continue to use the app's Chinese retry panel.

## Build

Open the `XAndroidApp` folder in Android Studio and build `:app:assembleDebug`.

## Verification note

The archive is structurally checked, but this environment does not have an Android SDK/Gradle build toolchain or a physical Android device. A successful build and real-device verification are therefore not claimed. X is a remote single-page application, so selectors may need adjustment if X changes its DOM.
