package com.x.mobile.wrapper

import android.annotation.SuppressLint
import android.app.Activity
import android.net.ConnectivityManager
import android.net.Uri
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Build
import android.view.WindowInsets
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceResponse
import androidx.webkit.WebViewAssetLoader
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import android.graphics.Color
import android.view.Gravity
import android.os.Handler
import android.os.Looper
import java.io.FileNotFoundException

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var root: FrameLayout
    private var errorView: TextView? = null
    private val prefs by lazy { getSharedPreferences("x_app_state", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private var lastBackPress = 0L
    private var vpnNoticeShown = false

    private val bridge = object {
        @JavascriptInterface
        fun showMessage(message: String) {
            handler.post { Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show() }
        }
    }

    private val bundledFontNames = setOf(
        "NotoSansSC-Regular.otf", "NotoSansSC-Bold.otf", "NotoSansMonoSC-Regular.otf",
        "NotoSansJP-Regular.otf", "NotoSansKR-Regular.otf",
        "Inter-Regular.ttf", "Inter-SemiBold.ttf",
        "NotoNaskhArabic-Regular.ttf", "NotoSansThai-Regular.ttf",
        "NotoSansDevanagari-Regular.ttf", "NotoSansHebrew-Regular.ttf",
        "NotoSansBengali-Regular.ttf"
    )

    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", object : WebViewAssetLoader.PathHandler {
                override fun handle(path: String): WebResourceResponse? {
                    val name = path.removePrefix("fonts/")
                    if (name !in bundledFontNames) return null
                    val mime = if (name.endsWith(".otf")) "font/otf" else "font/ttf"
                    val headers = mapOf(
                        "Access-Control-Allow-Origin" to "*",
                        "Cache-Control" to "public, max-age=31536000",
                        "X-Content-Type-Options" to "nosniff"
                    )
                    val fontStream = try {
                        assets.open("fonts/$name")
                    } catch (_: FileNotFoundException) {
                        // Some source archives may omit the optional font bundle.
                        // Let WebView fall back to system fonts instead of crashing.
                        return null
                    }
                    return WebResourceResponse(mime, null, 200, "OK", headers, fontStream)
                }
            })
            .build()
    }

    private fun withChineseLanguage(url: String): String {
        val parsed = Uri.parse(url)
        val host = parsed.host?.lowercase() ?: return url
        if (host !in setOf("x.com", "www.x.com", "twitter.com", "www.twitter.com")) return url
        val builder = parsed.buildUpon().clearQuery()
        parsed.queryParameterNames.forEach { key ->
            if (!key.equals("lang", ignoreCase = true)) {
                parsed.getQueryParameters(key).forEach { value -> builder.appendQueryParameter(key, value) }
            }
        }
        builder.appendQueryParameter("lang", "zh-cn")
        return builder.build().toString()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            // Android 15 / targetSdk 35 uses edge-to-edge by default. Keep WebView
            // content inside the system bars so X's top controls remain tappable.
            setOnApplyWindowInsetsListener { view, insets ->
                val topInset: Int
                val bottomInset: Int
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val bars = insets.getInsets(
                        WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout()
                    )
                    topInset = bars.top
                    bottomInset = bars.bottom
                } else {
                    topInset = insets.systemWindowInsetTop
                    bottomInset = insets.systemWindowInsetBottom
                }
                // Keep the WebView below the status bar and add a small visual
                // breathing space so X's fixed top controls are never under icons.
                val extraTop = (12 * resources.displayMetrics.density).toInt()
                view.setPadding(0, topInset + extraTop, 0, bottomInset)
                // Insets are handled here once; do not let a child apply them again.
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) WindowInsets.CONSUMED
                else insets.consumeSystemWindowInsets()
            }
        }
        webView = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            scrollBarStyle = View.SCROLLBARS_INSIDE_OVERLAY
        }
        root.addView(webView, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        // Explicitly request the initial insets after the root is attached.
        root.requestApplyInsets()

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            userAgentString = userAgentString // Keep Android WebView identity; do not spoof a browser.
        }
        webView.addJavascriptInterface(bridge, "XAppBridge")
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url) ?: super.shouldInterceptRequest(view, request)
            }

            override fun onPageFinished(view: WebView, url: String) {
                prefs.edit().putString("last_url", url).apply()
                injectButtonRules()
                hideError()
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) showError()
            }
        }

        val restored = prefs.getString("last_url", null)
        val startUrl = restored?.takeIf { it.startsWith("https://x.com") || it.startsWith("https://twitter.com") } ?: "https://x.com/"
        webView.loadUrl(withChineseLanguage(startUrl), mapOf("Accept-Language" to "zh-CN,zh;q=0.9,en;q=0.8"))
    }

    private fun injectButtonRules() {
        val script = """
            (function() {
              if (window.__xAppRulesInstalled) return;
              window.__xAppRulesInstalled = true;
              const norm = s => (s || '').replace(/[\u200B-\u200D\uFEFF]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
              const rules = [
                { id: 'phone', keys: ['continue with phone', 'use phone', 'continue with phone number', '使用手机继续', '使用电话号码继续', '手机号登录', '手机登录'], msg: '检测到该设备暂不支持手机号登录，请使用其它方式登录。' },
                { id: 'google', keys: ['continue with google', 'sign in with google', '使用 google 继续', 'google 继续', 'google 登录'], msg: '检测到该设备暂不支持 Google 登录，请使用其它方式登录。' },
                { id: 'apple', keys: ['continue with apple', 'sign in with apple', '使用 apple 继续', 'apple 继续', 'apple 登录'], msg: '检测到该设备暂不支持 Apple 登录，请使用其它方式登录。' }
              ];
              const controlSelector = 'button,a[role="button"],[role="button"],[role="menuitem"]';
              const getText = el => norm((el.innerText || el.textContent || '') + ' ' + (el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('data-testid') || '') + ' ' + (el.getAttribute('name') || ''));
              const getRule = el => {
                const t = getText(el);
                return rules.find(r => r.keys.some(k => t.includes(norm(k)))) || null;
              };
              function isStartupPage() {
                // Only the logged-out X entry screen at the root route is in scope.
                if (location.hostname !== 'x.com' && location.hostname !== 'www.x.com') return false;
                if (location.pathname !== '/') return false;
                if (document.querySelector('[data-testid="primaryColumn"], [data-testid="AppTabBar_Home_Link"], [data-testid="SideNav_AccountSwitcher_Button"]')) return false;
                const bodyText = norm(document.body ? (document.body.innerText || document.body.textContent || '') : '');
                return /log in|sign up|登录|注册|create account/.test(bodyText);
              }
              function replaceLoginLabel() {
                if (!document.body) return;
                // Replace the exact Chinese field label wherever X mounts the
                // login form (entry page, dialog, or a dynamically opened flow).
                const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
                let node;
                while ((node = walker.nextNode())) {
                  if (node.nodeValue && node.nodeValue.includes('电子邮箱或用户名')) {
                    node.nodeValue = node.nodeValue.replace(/电子邮箱或用户名/g, '@用户名登录');
                  }
                }
                document.querySelectorAll('[aria-label],[placeholder],[title]').forEach(el => {
                  ['aria-label','placeholder','title'].forEach(attr => {
                    const value = el.getAttribute(attr);
                    if (value && value.includes('电子邮箱或用户名')) {
                      el.setAttribute(attr, value.replace(/电子邮箱或用户名/g, '@用户名登录'));
                    }
                  });
                });
              }
              function removeGetApp() {
                if (!isStartupPage()) return;
                document.querySelectorAll('a,button,[role="button"]').forEach(el => {
                  const t = getText(el);
                  const href = norm(el.getAttribute('href'));
                  if (['get the app', '获取应用', 'get app', 'download the app', '下载应用'].some(k => t.includes(norm(k))) || /(^|\/)download-app(\/|$)/.test(href)) {
                    el.remove();
                  }
                });
              }
              function applyStartupPagePolicy() {
                // Keep startup-only cleanup scoped, but always update the login label.
                replaceLoginLabel();
                removeGetApp();
              }
              function tunePinnedNavigation() {
                const column = document.querySelector('[data-testid="primaryColumn"]');
                if (!column) return;
                const tabs = column.querySelector('[role="tablist"]');
                if (!tabs) return;
                // X may render the account/avatar + logo + action row as a banner
                // or as TopNavBar. Measure the real row instead of guessing its height.
                const candidates = [
                  column.querySelector('[data-testid="TopNavBar"]'),
                  column.querySelector('header[role="banner"]'),
                  column.querySelector(':scope > div > div > header')
                ].filter(Boolean);
                const topbar = candidates.find(el => el !== tabs && !el.contains(tabs));
                if (topbar) {
                  topbar.style.setProperty('position','sticky','important');
                  topbar.style.setProperty('top','0px','important');
                  topbar.style.setProperty('z-index','50','important');
                  const h = Math.max(56, Math.ceil(topbar.getBoundingClientRect().height));
                  tabs.style.setProperty('top', h + 'px','important');
                } else {
                  tabs.style.setProperty('top','0px','important');
                }
                tabs.style.setProperty('z-index','49','important');
              }
              function matchingRule(target) {
                const el = target && target.closest ? target.closest(controlSelector) : null;
                return el ? getRule(el) : null;
              }
              let lastNoticeAt = 0;
              function block(e) {
                const rule = matchingRule(e.target);
                if (!rule) return;
                e.preventDefault();
                e.stopPropagation();
                if (e.stopImmediatePropagation) e.stopImmediatePropagation();
                const now = Date.now();
                if (now - lastNoticeAt > 650) {
                  lastNoticeAt = now;
                  window.XAppBridge.showMessage(rule.msg);
                }
                return false;
              }
              ['click','pointerdown','touchstart','keydown'].forEach(type => document.addEventListener(type, block, true));
              const style = document.createElement('style');
              style.id = 'x-app-local-fonts';
              style.textContent = `
                @font-face{font-family:XAppInter;src:url('https://appassets.androidplatform.net/assets/fonts/Inter-Regular.ttf') format('truetype');font-weight:400;font-style:normal;font-display:swap}
                @font-face{font-family:XAppInter;src:url('https://appassets.androidplatform.net/assets/fonts/Inter-SemiBold.ttf') format('truetype');font-weight:600;font-style:normal;font-display:swap}
                @font-face{font-family:XAppNotoSansSC;src:url('https://appassets.androidplatform.net/assets/fonts/NotoSansSC-Regular.otf') format('opentype');font-weight:400;font-style:normal;font-display:swap}
                @font-face{font-family:XAppNotoSansSC;src:url('https://appassets.androidplatform.net/assets/fonts/NotoSansSC-Bold.otf') format('opentype');font-weight:700;font-style:normal;font-display:swap}
                @font-face{font-family:XAppNotoMonoSC;src:url('https://appassets.androidplatform.net/assets/fonts/NotoSansMonoSC-Regular.otf') format('opentype');font-weight:400;font-style:normal;font-display:swap}
                @font-face{font-family:XAppNotoSansJP;src:url('https://appassets.androidplatform.net/assets/fonts/NotoSansJP-Regular.otf') format('opentype');font-weight:400;font-style:normal;font-display:swap}
                @font-face{font-family:XAppNotoSansKR;src:url('https://appassets.androidplatform.net/assets/fonts/NotoSansKR-Regular.otf') format('opentype');font-weight:400;font-style:normal;font-display:swap}
                @font-face{font-family:XAppArabic;src:url('https://appassets.androidplatform.net/assets/fonts/NotoNaskhArabic-Regular.ttf') format('truetype');font-weight:400;font-style:normal;font-display:swap}
                @font-face{font-family:XAppThai;src:url('https://appassets.androidplatform.net/assets/fonts/NotoSansThai-Regular.ttf') format('truetype');font-weight:400;font-style:normal;font-display:swap}
                @font-face{font-family:XAppDevanagari;src:url('https://appassets.androidplatform.net/assets/fonts/NotoSansDevanagari-Regular.ttf') format('truetype');font-weight:400;font-style:normal;font-display:swap}
                @font-face{font-family:XAppHebrew;src:url('https://appassets.androidplatform.net/assets/fonts/NotoSansHebrew-Regular.ttf') format('truetype');font-weight:400;font-style:normal;font-display:swap}
                @font-face{font-family:XAppBengali;src:url('https://appassets.androidplatform.net/assets/fonts/NotoSansBengali-Regular.ttf') format('truetype');font-weight:400;font-style:normal;font-display:swap}
                html,body,body :not(svg):not(path):not(i):not([data-testid*="icon"]):not([aria-hidden="true"]){font-family:XAppInter,XAppNotoSansSC,XAppNotoSansJP,XAppNotoSansKR,XAppArabic,XAppThai,XAppDevanagari,XAppHebrew,XAppBengali,sans-serif!important}
                :lang(zh),:lang(zh) *{font-family:XAppNotoSansSC,XAppInter,XAppNotoSansJP,XAppNotoSansKR,XAppArabic,XAppThai,XAppDevanagari,XAppHebrew,XAppBengali,sans-serif!important}
                :lang(ja),:lang(ja) *{font-family:XAppNotoSansJP,XAppNotoSansSC,XAppInter,XAppNotoSansKR,XAppArabic,XAppThai,XAppDevanagari,XAppHebrew,XAppBengali,sans-serif!important}
                :lang(ko),:lang(ko) *{font-family:XAppNotoSansKR,XAppNotoSansSC,XAppInter,XAppNotoSansJP,XAppArabic,XAppThai,XAppDevanagari,XAppHebrew,XAppBengali,sans-serif!important}
                :lang(ar),:lang(ar) *,:lang(fa),:lang(fa) *,:lang(ur),:lang(ur) *{font-family:XAppArabic,XAppInter,XAppNotoSansSC,XAppNotoSansJP,XAppNotoSansKR,XAppThai,XAppDevanagari,XAppHebrew,XAppBengali,sans-serif!important}
                :lang(th),:lang(th) *{font-family:XAppThai,XAppInter,XAppNotoSansSC,XAppNotoSansJP,XAppNotoSansKR,XAppArabic,XAppDevanagari,XAppHebrew,XAppBengali,sans-serif!important}
                :lang(hi),:lang(hi) *,:lang(mr),:lang(mr) *,:lang(ne),:lang(ne) *{font-family:XAppDevanagari,XAppInter,XAppNotoSansSC,XAppNotoSansJP,XAppNotoSansKR,XAppArabic,XAppThai,XAppHebrew,XAppBengali,sans-serif!important}
                :lang(he),:lang(he) *,:lang(yi),:lang(yi) *{font-family:XAppHebrew,XAppInter,XAppNotoSansSC,XAppNotoSansJP,XAppNotoSansKR,XAppArabic,XAppThai,XAppDevanagari,XAppBengali,sans-serif!important}
                :lang(bn),:lang(bn) *{font-family:XAppBengali,XAppInter,XAppNotoSansSC,XAppNotoSansJP,XAppNotoSansKR,XAppArabic,XAppThai,XAppDevanagari,XAppHebrew,sans-serif!important}
                pre,code,kbd,samp{font-family:XAppNotoMonoSC,monospace!important}
                /* Fixed app-style top chrome. The Android container already applies
                   status-bar/cutout insets; these rows stay pinned while the feed scrolls. */
                :root{--xapp-topbar-height:56px}
                [data-testid="TopNavBar"],header[role="banner"],
                [data-testid="primaryColumn"]>div>div>header{
                  position:sticky!important;top:0!important;z-index:50!important;
                  min-height:56px!important;background:rgba(0,0,0,.97)!important;
                  padding-top:env(safe-area-inset-top,0px)!important;
                  backdrop-filter:blur(16px)!important;-webkit-backdrop-filter:blur(16px)!important
                }
                [data-testid="primaryColumn"] [role="tablist"]{
                  position:sticky!important;top:56px!important;z-index:49!important;
                  min-height:56px!important;display:flex!important;align-items:stretch!important;
                  background:rgba(0,0,0,.97)!important;
                  backdrop-filter:blur(16px)!important;-webkit-backdrop-filter:blur(16px)!important;
                  border-bottom:1px solid rgba(255,255,255,.12)!important
                }
                [data-testid="primaryColumn"] [role="tablist"] [role="tab"]{
                  min-height:56px!important;display:flex!important;align-items:center!important;
                  justify-content:center!important;flex:1 1 0!important;min-width:0!important;
                  padding:0 12px!important;font-size:15px!important;font-weight:650!important;
                  touch-action:manipulation!important
                }
                [data-testid="primaryColumn"]{min-height:0!important}
                [data-testid="primaryColumn"] [data-testid="primaryColumn"]{overflow:visible!important}
                button,[role="button"],[role="tab"],a{touch-action:manipulation}
                html,body{overscroll-behavior-y:none!important;scroll-behavior:auto!important;-webkit-overflow-scrolling:touch}
                ::-webkit-scrollbar{width:0!important;height:0!important}
              `;
              (document.head || document.documentElement).appendChild(style);
              applyStartupPagePolicy();
              tunePinnedNavigation();
              window.addEventListener('resize', tunePinnedNavigation, {passive:true});
              const observer = new MutationObserver(() => { applyStartupPagePolicy(); tunePinnedNavigation(); });
              observer.observe(document.documentElement, {childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['aria-label','data-testid','role','href']});
              window.__xAppRulesObserver = observer;
            })();
        """.trimIndent()
        webView.evaluateJavascript(script, null)
    }

    private fun showError() {
        if (errorView != null) return
        val label = TextView(this).apply {
            text = "暂时无法连接，请检查网络后重试"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            setPadding(32, 32, 32, 32)
            setOnClickListener { webView.reload(); root.removeView(this); errorView = null }
        }
        errorView = label
        root.addView(label, FrameLayout.LayoutParams(-1, -1))
    }

    private fun hideError() {
        errorView?.let { root.removeView(it) }
        errorView = null
    }

    override fun onPause() {
        super.onPause()
        webView.evaluateJavascript("window.scrollY", null)
        prefs.edit().putString("last_url", webView.url ?: "https://x.com").apply()
        CookieManager.getInstance().flush()
        webView.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
        showVpnNoticeIfNeeded()
    }

    private fun showVpnNoticeIfNeeded() {
        if (vpnNoticeShown) return
        val connectivity = getSystemService(CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
        val network = connectivity.activeNetwork ?: return
        val capabilities = connectivity.getNetworkCapabilities(network) ?: return
        if (!capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
            vpnNoticeShown = true
            Toast.makeText(this, "为获得更好的连接体验，请使用官方合作 VPN。", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            val now = System.currentTimeMillis()
            if (now - lastBackPress < 2000) {
                moveTaskToBack(true)
            } else {
                lastBackPress = now
                Toast.makeText(this, "再按一次返回键，应用将进入后台", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onDestroy() {
        webView.removeJavascriptInterface("XAppBridge")
        webView.destroy()
        super.onDestroy()
    }
}
