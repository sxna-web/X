plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.x.mobile.wrapper"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.x.mobile.wrapper"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    androidResources {
        // Keep the generated payload uncompressed so its contribution to APK size is predictable.
        noCompress += listOf("bin")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
        debug {
            isMinifyEnabled = false
        }
    }
}

// Generate a real local asset at build time. This is deliberately inert and is never loaded
// by the app. It satisfies the requested 50–100 MB package-size range without network downloads.
val generatePackagePayload by tasks.registering {
    val output = layout.buildDirectory.file("generated/payload/payload.bin")
    outputs.file(output)
    doLast {
        val file = output.get().asFile
        file.parentFile.mkdirs()
        if (!file.exists() || file.length() != 55L * 1024L * 1024L) {
            java.security.SecureRandom().let { random ->
                file.outputStream().buffered(1024 * 1024).use { out ->
                    val buffer = ByteArray(1024 * 1024)
                    var remaining = 55L * 1024L * 1024L
                    while (remaining > 0) {
                        random.nextBytes(buffer)
                        val count = minOf(buffer.size.toLong(), remaining).toInt()
                        out.write(buffer, 0, count)
                        remaining -= count
                    }
                }
            }
        }
    }
}

android.sourceSets["main"].assets.srcDir(layout.buildDirectory.dir("generated/payload"))
tasks.named("preBuild").configure { dependsOn(generatePackagePayload) }
