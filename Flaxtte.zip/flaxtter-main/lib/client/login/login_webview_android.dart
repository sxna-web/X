import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flaxtter/client/login/login_session.dart';
import 'package:flaxtter/client/client_account.dart';
import 'package:flaxtter/constants.dart';
import 'package:flaxtter/database/entities.dart';
import 'package:flaxtter/database/repository.dart';
import 'package:flaxtter/l10n/app_localizations.dart';
import 'package:flaxtter/utils/notifiers.dart';
import 'package:provider/provider.dart';
import 'package:webview_cookie_manager_plus/webview_cookie_manager_plus.dart';
import 'package:webview_flutter/webview_flutter.dart';

class LoginWebViewAndroid extends StatefulWidget {
  final LoginBrowserProfile profile;

  const LoginWebViewAndroid({
    super.key,
    required this.profile,
  });

  @override
  State<LoginWebViewAndroid> createState() => _LoginWebViewAndroidState();
}

class _LoginWebViewAndroidState extends State<LoginWebViewAndroid> {
  bool _csrfTokenFound = false;
  String? _csrfToken;
  Map<String, String>? _authHeader;
  bool _userFound = false;
  late final WebViewController _webviewController;
  final _webviewCookieManager = WebviewCookieManager();

  @override
  void initState() {
    super.initState();
    _webviewController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setUserAgent(widget.profile.userAgent)
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: _onPageFinished,
        onUrlChange: _onUrlChange,
      ))
      ..loadRequest(Uri.parse(loginStartUrl));
  }

  bool _isXHomeUrl(String? value) {
    if (value == null) return false;
    final uri = Uri.tryParse(value);
    return uri != null &&
        (uri.host == 'x.com' || uri.host.endsWith('.x.com')) &&
        uri.path.startsWith('/home');
  }

  Future<void> _onPageFinished(String url) async {
    if (!_isXHomeUrl(url) || !_csrfTokenFound || _userFound) {
      return;
    }

    var screenName = (await _webviewController.runJavaScriptReturningResult(
            "document.documentElement.outerHTML.match(/\"screen_name\":\"([^\"]+)\"/)?.[1] ?? '';"))
        .toString()
        .replaceAll('"', '');

    if (screenName.isEmpty) {
      if (mounted) Navigator.pop(context, false);
      return;
    }

    _userFound = true;
    await _saveAccount(screenName);
    if (mounted) Navigator.pop(context, true);
  }

  Future<void> _onUrlChange(UrlChange change) async {
    if (!_isXHomeUrl(change.url) || _csrfTokenFound) {
      return;
    }

    final cookies = await _webviewCookieManager.getCookies('https://x.com');
    final cookieValues = <String, String>{
      for (final cookie in cookies) cookie.name: cookie.value,
    };
    _csrfToken = cookieValues['ct0'];
    if (_csrfToken == null || _csrfToken!.isEmpty ||
        (cookieValues['auth_token'] ?? '').isEmpty) {
      return;
    }

    _authHeader = {
      'Cookie': cookieValues.entries
          .where((entry) =>
              entry.key == 'guest_id' ||
              entry.key == 'gt' ||
              entry.key == 'att' ||
              entry.key == 'auth_token' ||
              entry.key == 'ct0')
          .map((entry) => '${entry.key}=${entry.value}')
          .join('; '),
      'authorization': bearerToken,
      'x-csrf-token': _csrfToken!,
    };
    _csrfTokenFound = true;
  }

  Future<void> _saveAccount(String screenName) async {
    final database = await Repository.writable();
    await database.insert(
      tableAccounts,
      Account(id: _csrfToken!, screenName: screenName, authHeader: json.encode(_authHeader!)).toMap(),
    );
    await Repository.close();
    await TwitterAccount.initCheckXAccounts(forceInit: true);
    if (mounted) {
      Provider.of<AccountAddedNotifier>(context, listen: false).publish();
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(l10n.loginX)),
      body: WebViewWidget(controller: _webviewController),
    );
  }
}
