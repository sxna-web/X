package com.x.mobile.wrapper

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.net.ConnectivityManager
import android.net.Uri
import android.net.NetworkCapabilities
import android.net.Network
import android.net.NetworkRequest
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceResponse
import androidx.webkit.WebViewAssetLoader
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import android.graphics.Color
import android.view.Gravity
import android.os.Handler
import android.os.Looper

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var root: FrameLayout
    private var errorView: TextView? = null
    private val prefs by lazy { getSharedPreferences("x_app_state", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private var lastBackPress = 0L
    private var vpnNoticeShown = false
    private var retryPending = false
    private var retryAttempt = 0
    private var lastScrollY = 0
    private var restoreScrollPending = false
    private lateinit var fontButton: TextView
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private val retryRunnable = Runnable {
        if (!retryPending) return@Runnable
        if (isNetworkAvailable()) {
            retryPending = false
            hideError()
            webView.reload()
        } else {
            scheduleRetry()
        }
    }

    private fun scheduleRetry() {
        if (!retryPending) return
        handler.removeCallbacks(retryRunnable)
        val delaySeconds = (2L shl retryAttempt.coerceAtMost(4)).coerceAtMost(30L)
        retryAttempt = (retryAttempt + 1).coerceAtMost(4)
        handler.postDelayed(retryRunnable, delaySeconds * 1000L)
    }

    private val bridge = object {
        @JavascriptInterface
        fun showMessage(message: String) {
            handler.post { Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show() }
        }
    }

    private val bundledFontNames = setOf(
        "NotoSansSC.ttf", "NotoSerifSC.ttf", "NotoSansJP.ttf", "NotoSansKR.ttf", "Inter.ttf",
        "NotoSansArabic.ttf", "NotoSansThai.ttf"
    )

    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", object : WebViewAssetLoader.PathHandler {
                override fun handle(path: String): WebResourceResponse? {
                    val name = path.removePrefix("fonts/")
                    if (name !in bundledFontNames) return null
                    val mime = if (name.endsWith(".otf")) "font/otf" else "font/ttf"
                    val headers = mapOf(
                        "Access-Control-Allow-Origin" to "*",
                        "Cache-Control" to "public, max-age=31536000",
                        "X-Content-Type-Options" to "nosniff"
                    )
                    return WebResourceResponse(mime, null, 200, "OK", headers, assets.open("fonts/$name"))
                }
            })
            .build()
    }

    private fun isTrustedXUrl(url: String): Boolean {
        return try {
            val uri = Uri.parse(url)
            uri.scheme.equals("https", ignoreCase = true) &&
                uri.host?.lowercase() in setOf("x.com", "www.x.com", "twitter.com", "www.twitter.com")
        } catch (_: Exception) { false }
    }

    private fun withChineseLanguage(url: String): String {
        val parsed = Uri.parse(url)
        val host = parsed.host?.lowercase() ?: return url
        if (host !in setOf("x.com", "www.x.com", "twitter.com", "www.twitter.com")) return url
        val builder = parsed.buildUpon().clearQuery()
        parsed.queryParameterNames.forEach { key ->
            if (!key.equals("lang", ignoreCase = true)) {
                parsed.getQueryParameters(key).forEach { value -> builder.appendQueryParameter(key, value) }
            }
        }
        builder.appendQueryParameter("lang", "zh-cn")
        return builder.build().toString()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        if (Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }

        root = FrameLayout(this)
        // Respect the real system-bar insets on devices with cutouts/edge-to-edge.
        root.setOnApplyWindowInsetsListener { view, insets ->
            val top = if (Build.VERSION.SDK_INT >= 30) insets.getInsets(android.view.WindowInsets.Type.statusBars()).top else insets.systemWindowInsetTop
            val bottom = if (Build.VERSION.SDK_INT >= 30) {
                maxOf(
                    insets.getInsets(android.view.WindowInsets.Type.navigationBars()).bottom,
                    insets.getInsets(android.view.WindowInsets.Type.ime()).bottom
                )
            } else insets.systemWindowInsetBottom
            view.setPadding(0, top, 0, bottom)
            insets
        }
        webView = WebView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            scrollBarStyle = View.SCROLLBARS_INSIDE_OVERLAY
        }
        root.addView(webView, FrameLayout.LayoutParams(-1, -1))
        fontButton = TextView(this).apply {
            text = "Aa"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(6), dp(10), dp(6))
            contentDescription = "字体设置"
            setBackgroundColor(Color.rgb(35, 35, 35))
            elevation = dp(8).toFloat()
            setOnClickListener { showFontPicker() }
        }
        val fontButtonParams = FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.END)
        fontButtonParams.setMargins(0, dp(8), dp(8), 0)
        root.addView(fontButton, fontButtonParams)
        setContentView(root)

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            userAgentString = userAgentString // Keep Android WebView identity; do not spoof a browser.
        }
        webView.addJavascriptInterface(bridge, "XAppBridge")
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url) ?: super.shouldInterceptRequest(view, request)
            }

            override fun onPageFinished(view: WebView, url: String) {
                // A completed sub-navigation must not overwrite the saved home-page scroll
                // position or repeatedly force the old position onto every X page.
                injectButtonRules()
                applySelectedFont()
                installScrollStateKeeper()
                applyHomeHeaderRule()
                hideError()
                if (restoreScrollPending && isTrustedXUrl(url)) {
                    restoreScrollPending = false
                    val y = lastScrollY.coerceAtLeast(0)
                    if (y > 0) handler.postDelayed({
                        if (!isFinishing && !isDestroyed) view.evaluateJavascript("window.scrollTo(0, $y)", null)
                    }, 250L)
                }
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) {
                    view.stopLoading()
                    showError()
                }
            }
        }

        lastScrollY = prefs.getInt("scroll_y", 0)
        registerNetworkCallback()
        // Restore the actual WebView navigation state after configuration/process recreation.
        // If Android has no saved WebView state, fall back to the last trusted X URL.
        val restoredState = if (savedInstanceState != null) webView.restoreState(savedInstanceState) else null
        if (restoredState == null) {
            val restored = prefs.getString("last_url", null)
            val startUrl = restored?.takeIf { isTrustedXUrl(it) } ?: "https://x.com/"
            restoreScrollPending = restored != null && startUrl == restored && lastScrollY > 0
            webView.loadUrl(
                withChineseLanguage(startUrl),
                mapOf("Accept-Language" to "zh-CN,zh;q=0.9,en;q=0.8")
            )
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun showFontPicker() {
        val labels = arrayOf("简体中文黑体（Noto Sans SC）", "简体中文宋体（Noto Serif SC）", "日文字体（Noto Sans JP）", "韩文字体（Noto Sans KR）", "拉丁字体（Inter）", "系统默认字体")
        val keys = arrayOf("noto-sc", "noto-serif-sc", "noto-jp", "noto-kr", "inter", "system")
        val current = prefs.getString("font_family", "noto-sc") ?: "noto-sc"
        AlertDialog.Builder(this)
            .setTitle("应用字体")
            .setSingleChoiceItems(labels, keys.indexOf(current).coerceAtLeast(0)) { dialog, which ->
                prefs.edit().putString("font_family", keys[which]).apply()
                applySelectedFont()
                dialog.dismiss()
                Toast.makeText(this, "字体已切换", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun applySelectedFont() {
        val key = prefs.getString("font_family", "noto-sc") ?: "noto-sc"
        val family = when (key) {
            "noto-serif-sc" -> "XAppNotoSerifSC, XAppNotoSC, XAppNotoJP, XAppNotoKR, XAppInter, XAppArabic, XAppThai, sans-serif"
            "noto-jp" -> "XAppNotoJP, XAppNotoSC, XAppNotoKR, XAppInter, XAppArabic, XAppThai, sans-serif"
            "noto-kr" -> "XAppNotoKR, XAppNotoSC, XAppNotoJP, XAppInter, XAppArabic, XAppThai, sans-serif"
            "inter" -> "XAppInter, XAppNotoSC, XAppNotoJP, XAppNotoKR, XAppArabic, XAppThai, sans-serif"
            "system" -> null
            else -> "XAppNotoSC, XAppNotoJP, XAppNotoKR, XAppInter, XAppArabic, XAppThai, sans-serif"
        }
        val script = if (family == null) {
            "document.getElementById('x-app-selected-font')?.remove();"
        } else {
            """(function(){
              let s=document.getElementById('x-app-selected-font');
              if(!s){s=document.createElement('style');s.id='x-app-selected-font';(document.head||document.documentElement).appendChild(s);}
              s.textContent=""
                +"@font-face{font-family:XAppNotoSC;src:url('https://appassets.androidplatform.net/assets/fonts/NotoSansSC.ttf');font-weight:100 900;font-display:swap}"
                +"@font-face{font-family:XAppNotoSerifSC;src:url('https://appassets.androidplatform.net/assets/fonts/NotoSerifSC.ttf');font-weight:100 900;font-display:swap}"
                +"@font-face{font-family:XAppNotoJP;src:url('https://appassets.androidplatform.net/assets/fonts/NotoSansJP.ttf');font-weight:100 900;font-display:swap}"
                +"@font-face{font-family:XAppNotoKR;src:url('https://appassets.androidplatform.net/assets/fonts/NotoSansKR.ttf');font-weight:100 900;font-display:swap}"
                +"@font-face{font-family:XAppInter;src:url('https://appassets.androidplatform.net/assets/fonts/Inter.ttf');font-weight:100 900;font-display:swap}"
                +"@font-face{font-family:XAppArabic;src:url('https://appassets.androidplatform.net/assets/fonts/NotoSansArabic.ttf');font-weight:100 900;font-display:swap}"
                +"@font-face{font-family:XAppThai;src:url('https://appassets.androidplatform.net/assets/fonts/NotoSansThai.ttf');font-weight:100 900;font-display:swap}"
                +"html,body,body :not(svg):not(path):not(i):not([data-testid*=icon]){font-family:__FAMILY__!important}";
              document.fonts && document.fonts.ready.then(()=>{});
            })();""".replace("__FAMILY__", family)
        }
        webView.evaluateJavascript(script, null)
    }

    private fun installScrollStateKeeper() {
        val script = """(function(){
          if(window.__xAppScrollKeeper)return; window.__xAppScrollKeeper=true;
          let timer=0;
          function save(){
            const savedPath=location.pathname;
            clearTimeout(timer); timer=setTimeout(function(){
              try{
                const nodes=[...document.querySelectorAll('[data-testid]')].filter(e=>e.scrollHeight>e.clientHeight+80 && e.clientHeight>100);
                nodes.sort((a,b)=>b.scrollTop-a.scrollTop);
                const n=nodes[0];
                localStorage.setItem('xAppScroll:'+savedPath,JSON.stringify({y:window.scrollY||document.scrollingElement.scrollTop||0,testid:n?(n.getAttribute('data-testid')||''): '',top:n?n.scrollTop:0}));
              }catch(e){}
            },250);
          }
          function restore(){
            setTimeout(function(){
              try{const v=JSON.parse(localStorage.getItem('xAppScroll:'+location.pathname)||'null');if(!v)return;
                if(v.testid){const n=document.querySelector('[data-testid="'+CSS.escape(v.testid)+'"]');if(n)n.scrollTop=v.top||0;}
                if(v.y)window.scrollTo(0,v.y);
              }catch(e){}
            },700);
          }
          document.addEventListener('scroll',save,true);
          window.addEventListener('pagehide',save);
          window.addEventListener('popstate',restore);
          if(!window.__xAppScrollHistoryWrapped){
            window.__xAppScrollHistoryWrapped=true;
            ['pushState','replaceState'].forEach(name=>{const original=history[name];history[name]=function(){save();const result=original.apply(this,arguments);restore();return result;};});
          }
          restore();
        })();"""
        webView.evaluateJavascript(script, null)
    }

    private fun applyHomeHeaderRule() {
        val script = """(function(){
          function apply(){
            const old=document.getElementById('x-app-home-header');
            if(location.pathname!='/home'){if(old)old.remove();return;}
            if(old)return;
            const style=document.createElement('style');style.id='x-app-home-header';
            style.textContent='[data-testid="primaryColumn"] > div:first-child{position:sticky!important;top:0!important;z-index:30!important;background:var(--background-color,Canvas)!important}';
            (document.head||document.documentElement).appendChild(style);
          }
          if(!window.__xAppRouteWatch){
            window.__xAppRouteWatch=true;
            const wrap=name=>{const original=history[name];history[name]=function(){const result=original.apply(this,arguments);setTimeout(apply,80);return result;};};
            wrap('pushState');wrap('replaceState');window.addEventListener('popstate',()=>setTimeout(apply,80));
          }
          apply();
        })();"""
        webView.evaluateJavascript(script, null)
    }

    private fun injectButtonRules() {
        val script = """
            (function() {
              if (window.__xAppRulesInstalled) return;
              window.__xAppRulesInstalled = true;
              const norm = s => (s || '').replace(/[\u200B-\u200D\uFEFF]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
              const rules = [
                { id: 'phone', keys: ['continue with phone', 'use phone', 'continue with phone number', '使用手机继续', '使用电话号码继续', '手机号登录', '手机登录'], msg: '检测到该设备暂不支持手机号登录，请使用其它方式登录。' },
                { id: 'google', keys: ['continue with google', 'sign in with google', '使用 google 继续', 'google 继续', 'google 登录'], msg: '检测到该设备暂不支持 Google 登录，请使用其它方式登录。' },
                { id: 'apple', keys: ['continue with apple', 'sign in with apple', '使用 apple 继续', 'apple 继续', 'apple 登录'], msg: '检测到该设备暂不支持 Apple 登录，请使用其它方式登录。' }
              ];
              const controlSelector = 'button,a[role="button"],[role="button"],[role="menuitem"]';
              const getText = el => norm((el.innerText || el.textContent || '') + ' ' + (el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('data-testid') || '') + ' ' + (el.getAttribute('name') || ''));
              const getRule = el => {
                const t = getText(el);
                return rules.find(r => r.keys.some(k => t.includes(norm(k)))) || null;
              };
              function isStartupPage() {
                // Only the logged-out X entry screen at the root route is in scope.
                if (location.hostname !== 'x.com' && location.hostname !== 'www.x.com') return false;
                if (location.pathname !== '/') return false;
                if (document.querySelector('[data-testid="primaryColumn"], [data-testid="AppTabBar_Home_Link"], [data-testid="SideNav_AccountSwitcher_Button"]')) return false;
                const bodyText = norm(document.body ? (document.body.innerText || document.body.textContent || '') : '');
                return /log in|sign up|登录|注册|create account/.test(bodyText);
              }
              function removeGetApp() {
                if (!isStartupPage()) return;
                document.querySelectorAll('a,button,[role="button"]').forEach(el => {
                  const t = getText(el);
                  const href = norm(el.getAttribute('href'));
                  if (['get the app', '获取应用', 'get app', 'download the app', '下载应用'].some(k => t.includes(norm(k))) || /(^|\/)download-app(\/|$)/.test(href)) {
                    el.remove();
                  }
                });
              }
              function applyStartupPagePolicy() {
                // No global button hiding: normal X controls remain available on every page.
                removeGetApp();
                // Change only the visible placeholder; never alter input name/type/value or submit behavior.
                document.querySelectorAll('input').forEach(el => {
                  const p = norm(el.getAttribute('placeholder'));
                  if (p.includes('email') || p.includes('电子邮箱') || p.includes('邮箱') || p.includes('username or email') || p.includes('用户名或')) {
                    el.setAttribute('placeholder', '@用户名登录');
                    el.setAttribute('aria-label', '@用户名登录');
                  }
                });
              }
              function matchingRule(target) {
                const el = target && target.closest ? target.closest(controlSelector) : null;
                return el ? getRule(el) : null;
              }
              let lastNoticeAt = 0;
              function block(e) {
                const rule = matchingRule(e.target);
                if (!rule) return;
                e.preventDefault();
                e.stopPropagation();
                if (e.stopImmediatePropagation) e.stopImmediatePropagation();
                const now = Date.now();
                if (now - lastNoticeAt > 650) {
                  lastNoticeAt = now;
                  window.XAppBridge.showMessage(rule.msg);
                }
                return false;
              }
              ['click','pointerdown','touchstart','keydown'].forEach(type => document.addEventListener(type, block, true));
              // Do not force a global font family: X's own in-app font selector must remain authoritative.
              const style = document.createElement('style');
              style.id = 'x-app-layout-rules';
              style.textContent = `
                html,body{overscroll-behavior-y:none!important;scroll-behavior:auto!important;-webkit-overflow-scrolling:touch}
                ::-webkit-scrollbar{width:0!important;height:0!important}
              `;
              const oldStyle = document.getElementById('x-app-layout-rules');
              if (oldStyle) oldStyle.remove();
              (document.head || document.documentElement).appendChild(style);
              applyStartupPagePolicy();
              const observer = new MutationObserver(() => applyStartupPagePolicy());
              observer.observe(document.documentElement, {childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['aria-label','data-testid','role','href']});
              window.__xAppRulesObserver = observer;
            })();
        """.trimIndent()
        webView.evaluateJavascript(script, null)
    }

    private fun showError() {
        if (errorView != null) return
        retryPending = true
        val label = TextView(this).apply {
            text = "暂时无法连接\n请检查网络，恢复连接后将自动重试"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            setPadding(32, 32, 32, 32)
            setOnClickListener {
                if (isNetworkAvailable()) { retryPending = false; hideError(); webView.reload() }
                else text = "网络尚未连接\n恢复连接后将自动重试"
            }
        }
        errorView = label
        root.addView(label, FrameLayout.LayoutParams(-1, -1))
        retryAttempt = 0
        scheduleRetry()
    }

    private fun isNetworkAvailable(): Boolean {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private fun registerNetworkCallback() {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
        if (Build.VERSION.SDK_INT >= 23) {
            val callback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    handler.post {
                        if (errorView != null) retryPending = true
                        if (retryPending && isNetworkAvailable()) {
                            handler.removeCallbacks(retryRunnable)
                            retryAttempt = 0
                            retryRunnable.run()
                        }
                    }
                }

                override fun onLost(network: Network) {
                    handler.post {
                        // Ignore a lost old network during Wi-Fi/mobile handover if another
                        // validated Internet connection is already active.
                        if (!isNetworkAvailable() && isTrustedXUrl(webView.url.orEmpty())) {
                            webView.stopLoading()
                            showError()
                        }
                    }
                }
            }
            networkCallback = callback
            try {
                if (Build.VERSION.SDK_INT >= 24) {
                    cm.registerDefaultNetworkCallback(callback)
                } else {
                    val request = NetworkRequest.Builder()
                        .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                        .build()
                    cm.registerNetworkCallback(request, callback)
                }
            } catch (_: Exception) {
                networkCallback = null
            }
        }
    }

    private fun hideError() {
        errorView?.let { root.removeView(it) }
        errorView = null
        retryPending = false
        retryAttempt = 0
        handler.removeCallbacks(retryRunnable)
    }

    override fun onPause() {
        super.onPause()
        webView.evaluateJavascript("window.scrollY") { value ->
            value?.toIntOrNull()?.let { y -> lastScrollY = y; prefs.edit().putInt("scroll_y", y).apply() }
        }
        val currentUrl = webView.url.orEmpty()
        if (isTrustedXUrl(currentUrl)) prefs.edit().putString("last_url", currentUrl).apply()
        CookieManager.getInstance().flush()
        webView.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
        showVpnNoticeIfNeeded()
    }

    private fun showVpnNoticeIfNeeded() {
        if (vpnNoticeShown) return
        val connectivity = getSystemService(CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
        val network = connectivity.activeNetwork ?: return
        val capabilities = connectivity.getNetworkCapabilities(network) ?: return
        if (!capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
            vpnNoticeShown = true
            Toast.makeText(this, "为获得更好的连接体验，请使用官方合作 VPN。", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            val now = System.currentTimeMillis()
            if (now - lastBackPress < 2000) {
                moveTaskToBack(true)
            } else {
                lastBackPress = now
                Toast.makeText(this, "再按一次返回键，应用将进入后台", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onDestroy() {
        handler.removeCallbacks(retryRunnable)
        val cm = getSystemService(CONNECTIVITY_SERVICE) as? ConnectivityManager
        networkCallback?.let { try { cm?.unregisterNetworkCallback(it) } catch (_: Exception) { } }
        webView.removeJavascriptInterface("XAppBridge")
        webView.destroy()
        super.onDestroy()
    }
}
