# X Android WebView wrapper

## V13 responsive layout corrections

- Uses a consistent edge-to-edge window layout and reads the live Android system-bar and display-cutout insets. The WebView viewport begins exactly below the measured status-bar/notch safe area; there is no fixed dp/px top spacer or extra height compensation. Left/right cutout and bottom navigation insets are also applied when present.
- Insets are recalculated whenever Android dispatches updated window insets, so rotation, display mode, and device-specific status-bar dimensions are handled by the OS values rather than a guessed constant.
- The home feed's `为你推荐 / 正在关注` (or `For you / Following`) tab strip remains in normal document flow while the avatar/header area is visible. It becomes fixed only when the tab strip itself reaches the top of the WebView viewport, and returns to normal flow when scrolling back above it.
- Login label replacement continues to target `@用户名登录`, with a narrow visual fallback that avoids input and button controls.
- Main-frame network and HTTP failures show the app's Chinese retry panel. The panel is kept visible until a subsequent main-frame navigation succeeds, rather than being dismissed by the WebView's error-page `onPageFinished` callback.
- No `.yml` files are included or modified.

## Build

Open the `XAndroidApp` folder in Android Studio and build `:app:assembleDebug`.

## Verification note

The ZIP archive can be structurally checked here, but this environment does not have an Android SDK/Gradle build toolchain or a physical Android device. A successful Android build and real-device behavior are therefore not claimed. X is a remote single-page application, so its DOM selectors may need adjustment if X changes its page structure.
