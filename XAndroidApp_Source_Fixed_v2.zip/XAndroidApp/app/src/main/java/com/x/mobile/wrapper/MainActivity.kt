package com.x.mobile.wrapper

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import android.graphics.Color
import android.view.Gravity
import android.os.Handler
import android.os.Looper

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var root: FrameLayout
    private var errorView: TextView? = null
    private val prefs by lazy { getSharedPreferences("x_app_state", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private var lastBackPress = 0L

    private val bridge = object {
        @JavascriptInterface
        fun showMessage(message: String) {
            handler.post { Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show() }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        root = FrameLayout(this)
        webView = WebView(this)
        root.addView(webView, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            userAgentString = userAgentString // Keep Android WebView identity; do not spoof a browser.
        }
        webView.addJavascriptInterface(bridge, "XAppBridge")
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                prefs.edit().putString("last_url", url).apply()
                injectButtonRules()
                hideError()
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) showError()
            }
        }

        val restored = prefs.getString("last_url", null)
        webView.loadUrl(restored?.takeIf { it.startsWith("https://x.com") || it.startsWith("https://twitter.com") } ?: "https://x.com")
    }

    private fun injectButtonRules() {
        val script = """
            (function() {
              if (window.__xAppRulesInstalled) return;
              window.__xAppRulesInstalled = true;
              const normalize = s => (s || '').replace(/\s+/g, ' ').trim().toLowerCase();
              const rules = [
                { words: ['continue with google', 'sign in with google', '使用 google 继续'], msg: '当前设备的 Google 服务暂不可用，请检查 Google 服务环境，或使用其它方式登录。' },
                { words: ['continue with apple', 'sign in with apple', '使用 apple 继续'], msg: '当前设备暂不支持 Apple 登录，请使用其它方式登录。' },
                { words: ['continue with phone', 'use phone', '使用手机继续'], msg: '当前设备没有可用于登录的受支持手机号，请使用其它方式登录。' }
              ];
              function scan() {
                document.querySelectorAll('a,button,[role="button"]').forEach(el => {
                  const t = normalize(el.innerText || el.getAttribute('aria-label'));
                  if (!t) return;
                  if (t === 'get the app' || t === '获取应用') {
                    el.style.visibility = 'hidden';
                    el.style.pointerEvents = 'none';
                    el.setAttribute('aria-hidden', 'true');
                  }
                });
              }
              document.addEventListener('click', function(e) {
                const el = e.target && e.target.closest ? e.target.closest('a,button,[role="button"]') : null;
                if (!el) return;
                const t = normalize(el.innerText || el.getAttribute('aria-label'));
                for (const r of rules) {
                  if (r.words.some(w => t.includes(normalize(w)))) {
                    e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
                    window.XAppBridge.showMessage(r.msg);
                    return false;
                  }
                }
              }, true);
              scan();
              new MutationObserver(scan).observe(document.documentElement, {childList:true, subtree:true, attributes:true});
            })();
        """.trimIndent()
        webView.evaluateJavascript(script, null)
    }

    private fun showError() {
        if (errorView != null) return
        val label = TextView(this).apply {
            text = "暂时无法连接，请检查网络后重试"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            setPadding(32, 32, 32, 32)
            setOnClickListener { webView.reload(); root.removeView(this); errorView = null }
        }
        errorView = label
        root.addView(label, FrameLayout.LayoutParams(-1, -1))
    }

    private fun hideError() {
        errorView?.let { root.removeView(it) }
        errorView = null
    }

    override fun onPause() {
        super.onPause()
        webView.evaluateJavascript("window.scrollY", null)
        prefs.edit().putString("last_url", webView.url ?: "https://x.com").apply()
        CookieManager.getInstance().flush()
        webView.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            val now = System.currentTimeMillis()
            if (now - lastBackPress < 2000) {
                moveTaskToBack(true)
            } else {
                lastBackPress = now
                Toast.makeText(this, "再按一次返回键，应用将进入后台", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onDestroy() {
        webView.removeJavascriptInterface("XAppBridge")
        webView.destroy()
        super.onDestroy()
    }
}
