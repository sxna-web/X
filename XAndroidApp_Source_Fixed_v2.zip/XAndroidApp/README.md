# X Android App

独立 Android Studio 项目，应用名称 X，包名 `com.x.mobile.wrapper`。

## 构建环境
- Android Studio（建议使用兼容 Android Gradle Plugin 8.7.3 的版本）
- JDK 17
- Android SDK 35
- Gradle 8.9（Android Studio 可自动下载）

打开项目后执行 `:app:assembleDebug` 或 `:app:assembleRelease`。

## 安装包体积
构建任务会在本地生成 55 MiB 的惰性数据资源 `payload.bin`，不联网下载、不参与应用逻辑，并以不压缩方式放入 APK。最终 APK 仍需实际构建后测量；若 APK 文件不在 50–100 MB 之间，不视为通过体积验收。

## 重要说明
- 本项目使用 Android WebView 显示 X 官方服务，但应用界面不显示浏览器地址栏或浏览器控件。
- X 官方可能限制某些内嵌登录环境。必须在真实设备上测试邮箱/用户名、密码、验证码及双重验证；不能保证 X 服务端永远允许内嵌环境。
- 登录状态依赖 X 官方 Cookie/会话机制，不保存明文密码；X 可因安全策略要求重新验证。
- Google、Apple、手机号入口拦截基于页面按钮文字识别，X 更新界面后需要重新测试和维护。不得拦截账号密码、验证码或必要安全验证流程。
- “获取应用”入口隐藏并禁用点击区域，保留原页面背景。
- 这是第一版工程起点，尚未在真实 Android 设备上编译、安装或验收。
