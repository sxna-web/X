# X Android App

这是一个 Android WebView 封装项目。项目目标是保留 X 的正常账号登录、时间线、互动、私信和导航能力，并尽量采用简体中文界面。

## 当前实现

- 使用 Android 原生 Activity + WebView 承载 X。
- 请求简体中文语言参数，并设置简体中文优先的 Accept-Language。
- 保存最近访问的 X 页面地址、滚动位置及 WebView Cookie；系统重建 Activity 时尝试恢复 WebView 导航状态。
- 根据系统状态栏和导航栏 Insets 调整内容区域，并保留键盘 `adjustResize` 行为。
- 网络异常时显示应用内中文提示；网络恢复后自动重试，也支持点击提示手动重试。
- 不再通过全局 CSS 强制覆盖 X 字体，避免与 X 自身的字体设置冲突。
- GitHub Actions 构建后检查 APK ZIP 完整性、必要文件、包名（可用 aapt 时），输出文件大小和 SHA-256。

## 尚未验证或未实现

- 尚未通过真实设备验证不同刘海/挖孔屏、键盘、横竖屏、后台恢复和断网重连行为。
- X 首页顶部固定、内容区独立滚动尚未改动。由于 X 页面 DOM 和滚动容器会变化，未经验证强行注入固定布局可能破坏其他页面。
- 字体选择交由 X 自身设置管理；本项目没有内置字体文件，也没有自行实现字体选择记忆界面。
- 本项目 ZIP 未包含 Gradle Wrapper；GitHub Actions 使用托管 runner 上的 Gradle 8.9 构建。
- 尚未完成本次源码的实际 APK 构建、安装和登录回归测试。工作流报告实际 APK 大小，不设置 APK 大小硬性失败门槛。

## GitHub Actions

将整个 `XAndroidApp` 目录内容放到仓库根目录（确保根目录直接存在 `settings.gradle.kts`、`build.gradle.kts`、`app/` 和 `.github/workflows/build.yml`），推送到 `main` 或手动运行 `Android APK Build`。成功后在 Actions 对应运行记录的 Artifacts 下载 `X-Android-debug-APK`。

## 重要说明

不要只上传 ZIP 文件而不解压到仓库根目录；否则工作流无法在根目录找到 Gradle 项目。不要把字体文件或无关填充数据放入仓库。任何页面结构调整都应先在实际 X 页面验证，避免影响登录、私信、发帖和其他页面。
